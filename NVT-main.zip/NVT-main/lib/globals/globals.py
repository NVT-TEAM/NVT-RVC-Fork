DoFormant: bool = False
Quefrency: float = 8.0
Timbre: float = 1.2

NotesOrHertz: bool = False